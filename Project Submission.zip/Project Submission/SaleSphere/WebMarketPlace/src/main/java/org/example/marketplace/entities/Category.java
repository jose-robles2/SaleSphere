package org.example.marketplace.entities;

public enum Category {
    FIREARM,
    ALCOHOL,
    MEDICINE,
    DRUGS,
    TECHNOLOGY,
    TOBACCO
}